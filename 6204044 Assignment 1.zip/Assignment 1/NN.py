#!/usr/bin/env python
# coding: utf-8

# In[6]:


import numpy as np 

import ACML

#inputs
X = np.array(([1,0,0,0,0,0,0,0],
              [0,1,0,0,0,0,0,0],
              [0,0,1,0,0,0,0,0],
              [0,0,0,1,0,0,0,0],
              [0,0,0,0,1,0,0,0],
              [0,0,0,0,0,1,0,0],
              [0,0,0,0,0,0,1,0],
              [0,0,0,0,0,0,0,1]), dtype=int)



#output
y = X



#how to set learning rate and decay rate? internet says 0.1 is kinda default! 
#This is the best final error after trial and error
ACML.Neural_Network(X, y, 8, 8, 3, 0.1, 0.00001, 800000)


# In[ ]:




