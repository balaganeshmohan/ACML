import numpy as np 

def sigmoid(z):               #sigmoid activation function
    return 1/(1+np.exp(-z))


def sigmoid_prime(output):    #derivative of sigmoid function
    return output * (1 - output) 

#Forward propogation
def forward(X_bias, W1, W2):  #W1 and W2 are weights for input and hidden layer respectively


    z = np.dot(X_bias, W1)         #Applying activation functions to the inputs.
    a2 = sigmoid(z)
    

    numrows_hid = np.size(a2, axis=0)           #Adding bias 
    bias_hid = np.array([1.] * numrows_hid)
    a21 = np.column_stack((bias_hid, a2)) 

    z2 = np.dot(a21, W2)                       #Activation function for the hidden layer
    output = sigmoid(z2)
    return output, a21                  
    
#Back propagation 
def backpropogation(y, output, W1, W2, alpha, Lambda, numrows, X_bias, a21):   


    error = -(y - output)               #cost function

#Delta for hidden to output error

    delta2 = error * sigmoid_prime(output) 

#Delta for input to hidden error
   

    delta1 = np.dot(delta2, W2.T) * (a21) * (1 - a21)


#Partial derivatives
    gradient_W2 = np.dot(a21.T, delta2) 
    gradient_W1 = np.dot(X_bias.T, delta1[:,1:]) #bias term is excluded

#updating weights
    W2 = W2 - (alpha * ((gradient_W2 / numrows) + (Lambda * W2)))
    W1 = W1 - (alpha * ((gradient_W1 / numrows) + (Lambda * W1)))    
    return W1, W2


#Initalizing class neural network
def Neural_Network(X, y, inputLayerSize, outputLayerSize, hiddenLayerSize, alpha, Lambda, epochs):

#how to set alpha and lambda values??

#Bias variable added to X as 1 
    numrows = np.size(X, axis=0) 
    bias = np.array([1.] * numrows)
    X_bias = np.column_stack((bias, X)) 




#assign weights w1 and w2 as random values, no need to normalize since data is already 1's and 0's; +1 is bias.
    W1 = np.random.rand(inputLayerSize + 1, hiddenLayerSize)  
    W2 = np.random.rand(hiddenLayerSize + 1, outputLayerSize)

#Iterations
    i = 0
    while i < epochs:
        i += 1 
        [output, a21] = forward(X_bias, W1, W2)
        [W1, W2] = backpropogation(y, output, W1, W2, alpha, Lambda, numrows, X_bias, a21)
        
        if np.mean(np.square(y - output)) <= 0.01:
            print("Final iteration: \n" + str(i)) 
            break 
    
    print("Actual: \n" + str(y)) 
    print("Predicted: \n" + str(np.around(output, 2)))
    print("Final Error: \n" + str(np.mean(np.square(y - output)))) 
    print("Weights 1: \n" + str(np.around(W1, 2)))
    print("Weights 2: \n" + str(np.around(W2, 2)))
    
    




